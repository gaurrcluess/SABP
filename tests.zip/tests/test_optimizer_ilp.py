from datetime import datetime

from app.models.schemas import Block, Criticality, ScoredRequest
from app.services.optimizer_ilp import solve_weekly


def block(**overrides):
    base = dict(
        block_id="BLK-1",
        section_id="SEC-A",
        track_id="TRK-1",
        block_start=datetime(2026, 9, 7, 8, 0),
        block_end=datetime(2026, 9, 7, 14, 0),
        allocated_duration_hrs=4,
        used_duration_hrs=0,
        assigned_resources=[],
    )
    base.update(overrides)
    return Block(**base)


def req(**overrides):
    base = dict(
        request_id="R1",
        section_id="SEC-A",
        track_id="TRK-1",
        asset_type="rail",
        department="Engineering",
        earliest_start=datetime(2026, 9, 7, 8, 0),
        latest_end=datetime(2026, 9, 7, 10, 0),
        estimated_duration_hrs=2,
        required_resources=[],
        criticality=Criticality.MEDIUM,
        overdue_days=0,
        sla_days=30,
        impact_trains_affected=0,
    )
    base.update(overrides)
    return ScoredRequest(**base)


def test_capacity_respected():
    b = block(allocated_duration_hrs=3)
    r1 = req(request_id="R1", estimated_duration_hrs=2, criticality=Criticality.LOW)
    r2 = req(request_id="R2", estimated_duration_hrs=2, criticality=Criticality.LOW)
    scheduled_blocks, unscheduled, captured, possible = solve_weekly([r1, r2], [b])
    total_scheduled_hrs = sum(
        2 for sb in scheduled_blocks for _ in sb.scheduled_request_ids
    )
    assert total_scheduled_hrs <= 3  # can't exceed block capacity
    assert len(unscheduled) == 1


def test_hard_priority_wins_capacity_conflict():
    b = block(allocated_duration_hrs=2)
    critical_overdue = req(
        request_id="R-CRIT", estimated_duration_hrs=2,
        criticality=Criticality.CRITICAL, overdue_days=40, sla_days=30,
    )
    low = req(request_id="R-LOW", estimated_duration_hrs=2, criticality=Criticality.LOW)
    scheduled_blocks, unscheduled, captured, possible = solve_weekly([critical_overdue, low], [b])
    scheduled_ids = {rid for sb in scheduled_blocks for rid in sb.scheduled_request_ids}
    assert "R-CRIT" in scheduled_ids
    assert "R-LOW" not in scheduled_ids


def test_infeasible_request_reported_unscheduled():
    b = block(section_id="SEC-A", track_id="TRK-1")
    r = req(request_id="R-OFF", section_id="SEC-Z", track_id="TRK-9")
    scheduled_blocks, unscheduled, captured, possible = solve_weekly([r], [b])
    assert unscheduled[0].request_id == "R-OFF"
    assert "No feasible block" in unscheduled[0].reason
