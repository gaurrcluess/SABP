from datetime import datetime, timedelta

from app.models.schemas import Criticality, ScoredRequest
from app.services.scoring import is_hard_priority, priority_score, urgency_score, impact_score


def make_request(**overrides):
    base = dict(
        request_id="R1",
        section_id="SEC-A",
        track_id="TRK-1",
        asset_type="rail",
        department="Engineering",
        earliest_start=datetime(2026, 9, 7, 8, 0),
        latest_end=datetime(2026, 9, 7, 10, 0),
        estimated_duration_hrs=2,
        required_resources=[],
        criticality=Criticality.MEDIUM,
        overdue_days=0,
        sla_days=30,
        impact_trains_affected=0,
    )
    base.update(overrides)
    return ScoredRequest(**base)


def test_higher_criticality_scores_higher():
    low = make_request(criticality=Criticality.LOW)
    critical = make_request(criticality=Criticality.CRITICAL)
    assert priority_score(critical) > priority_score(low)


def test_urgency_caps_at_sla_ratio_one():
    req = make_request(overdue_days=90, sla_days=30)
    assert urgency_score(req) == 10.0


def test_impact_scales_with_trains_affected():
    few = make_request(impact_trains_affected=2)
    many = make_request(impact_trains_affected=25)
    assert impact_score(many) > impact_score(few)
    assert impact_score(many) == 10.0  # saturates


def test_hard_priority_flag():
    req = make_request(criticality=Criticality.CRITICAL, overdue_days=31, sla_days=30)
    assert is_hard_priority(req)
    not_hard = make_request(criticality=Criticality.HIGH, overdue_days=31, sla_days=30)
    assert not is_hard_priority(not_hard)
