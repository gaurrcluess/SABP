"""
FastAPI entrypoint for the Optimization API.

Scope: takes maintenance requests + available blocks (from Block Maker,
or mock data), scores them by priority, and runs the scheduler
appropriate to the planning horizon (ILP for weekly, GA for monthly).
Endpoint paths match what RailSync's frontend (src/lib/api.js) expects.
"""

import uuid

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from app.models.schemas import OptimizationRequest, OptimizationResponse
from app.services import data_loader, plan_store
from app.services.optimizer_ga import solve_monthly
from app.services.optimizer_ilp import solve_weekly

app = FastAPI(
    title="Optimization API",
    description="Priority scoring + block schedule optimization (weekly ILP / monthly GA).",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/health")
def health_check():
    return {"status": "ok"}


@app.post("/api/optimization/generate", response_model=OptimizationResponse)
def generate_optimization(payload: OptimizationRequest | None = None):
    payload = payload or OptimizationRequest()
    try:
        requests = payload.requests or data_loader.load_requests()
        blocks = payload.blocks or data_loader.load_blocks()
        calendar = payload.planning_calendar or data_loader.load_calendar()
    except FileNotFoundError as exc:
        raise HTTPException(status_code=500, detail=f"Missing data file: {exc}") from exc

    if calendar.period_type == "weekly":
        scheduled_blocks, unscheduled, captured, possible = solve_weekly(requests, blocks)
        method = "ilp"
    else:
        scheduled_blocks, unscheduled, captured, possible = solve_monthly(requests, blocks)
        method = "genetic"

    plan = OptimizationResponse(
        plan_id=f"PLAN-{uuid.uuid4().hex[:8]}",
        period_id=calendar.period_id,
        period_type=calendar.period_type,
        method=method,
        scheduled_blocks=scheduled_blocks,
        unscheduled_requests=unscheduled,
        total_requests_scored=len(requests),
        total_priority_captured=captured,
        total_priority_possible=possible,
    )
    plan_store.save(plan)
    return plan


@app.get("/api/plans/weekly", response_model=OptimizationResponse)
def get_weekly_plan():
    plan = plan_store.get_latest("weekly")
    if not plan:
        raise HTTPException(status_code=404, detail="No weekly plan generated yet.")
    return plan


@app.get("/api/plans/monthly", response_model=OptimizationResponse)
def get_monthly_plan():
    plan = plan_store.get_latest("monthly")
    if not plan:
        raise HTTPException(status_code=404, detail="No monthly plan generated yet.")
    return plan


@app.get("/api/plans/{plan_id}", response_model=OptimizationResponse)
def get_plan(plan_id: str):
    plan = plan_store.get(plan_id)
    if not plan:
        raise HTTPException(status_code=404, detail=f"Plan {plan_id} not found.")
    return plan


@app.get("/api/blocks")
def get_blocks():
    return plan_store.all_blocks()


@app.get("/api/blocks/{block_id}")
def get_block_details(block_id: str):
    for block in plan_store.all_blocks():
        if block.block_id == block_id:
            return block
    raise HTTPException(status_code=404, detail=f"Block {block_id} not found.")
