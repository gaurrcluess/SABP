"""
Pydantic schemas for the Optimization API.

Block Maker's `MaintenanceRequest` / `Block` intentionally carry no
criticality, score, or optimization fields. This service extends the
request side with the fields it needs to score and schedule, and
extends the block side with the fields the frontend expects back
(`priority_score`, `optimization_reasons`).
"""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import List, Optional

from pydantic import BaseModel, Field, field_validator


class Criticality(str, Enum):
    LOW = "Low"
    MEDIUM = "Medium"
    HIGH = "High"
    CRITICAL = "Critical"


class ScoredRequest(BaseModel):
    """A maintenance request with the fields needed for priority scoring.

    Superset of Block Maker's MaintenanceRequest — same identity fields
    (request_id/section_id/track_id/asset_type/earliest_start/latest_end/
    estimated_duration_hrs/required_resources) plus scoring inputs.
    """

    request_id: str
    section_id: str
    track_id: str
    asset_type: str
    department: str
    earliest_start: datetime
    latest_end: datetime
    estimated_duration_hrs: float = Field(gt=0)
    required_resources: List[str] = Field(default_factory=list)

    criticality: Criticality
    overdue_days: int = Field(default=0, ge=0)
    sla_days: int = Field(default=30, gt=0)
    impact_trains_affected: int = Field(default=0, ge=0)

    @field_validator("required_resources", mode="before")
    @classmethod
    def _split_csv_resources(cls, v):
        if isinstance(v, str):
            return [r.strip() for r in v.split(";") if r.strip()]
        return v

    @field_validator("latest_end")
    @classmethod
    def _end_after_start(cls, v, info):
        start = info.data.get("earliest_start")
        if start and v <= start:
            raise ValueError("latest_end must be after earliest_start")
        return v


class Block(BaseModel):
    """Mirrors Block Maker's Block — the unit we're assigning requests into."""

    block_id: str
    section_id: str
    track_id: str
    block_start: datetime
    block_end: datetime
    allocated_duration_hrs: float = Field(gt=0)
    used_duration_hrs: float = Field(default=0, ge=0)
    assigned_resources: List[str] = Field(default_factory=list)
    is_new: bool = False

    @field_validator("assigned_resources", mode="before")
    @classmethod
    def _split_csv_resources(cls, v):
        if isinstance(v, str):
            return [r.strip() for r in v.split(";") if r.strip()]
        return v

    @property
    def remaining_duration_hrs(self) -> float:
        return round(self.allocated_duration_hrs - self.used_duration_hrs, 4)


class ScheduledBlock(Block):
    """A Block annotated with the optimizer's decisions for this period."""

    scheduled_request_ids: List[str] = Field(default_factory=list)
    priority_score: float = 0.0
    optimization_reasons: List[str] = Field(default_factory=list)


class UnscheduledRequest(BaseModel):
    request_id: str
    priority_score: float
    reason: str


class PlanningCalendar(BaseModel):
    period_id: str
    period_type: str  # "weekly" or "monthly"
    start_date: datetime
    end_date: datetime

    @field_validator("period_type")
    @classmethod
    def _valid_period_type(cls, v):
        if v not in ("weekly", "monthly"):
            raise ValueError("period_type must be 'weekly' or 'monthly'")
        return v


class OptimizationRequest(BaseModel):
    """Body for POST /optimization/generate.

    Either supply requests/blocks/calendar directly, or leave them null
    to fall back to mock data under /data (mirrors Block Maker's pattern).
    """

    requests: Optional[List[ScoredRequest]] = None
    blocks: Optional[List[Block]] = None
    planning_calendar: Optional[PlanningCalendar] = None


class OptimizationResponse(BaseModel):
    plan_id: str
    period_id: str
    period_type: str
    method: str  # "ilp" (weekly) or "genetic" (monthly)
    scheduled_blocks: List[ScheduledBlock]
    unscheduled_requests: List[UnscheduledRequest] = Field(default_factory=list)
    total_requests_scored: int
    total_priority_captured: float
    total_priority_possible: float
