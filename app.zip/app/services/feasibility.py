"""
Hard feasibility checks between a request and a block, mirroring
Block Maker's compatibility rules so the optimizer only ever proposes
legal assignments. This is deliberately independent of Block Maker's
codebase (separate service) but keeps the same constraint model.
"""

from __future__ import annotations

from app.models.schemas import Block, ScoredRequest

EXCLUSIVE_RESOURCES = {"crane", "possession_team", "tamping_machine"}


def is_feasible(req: ScoredRequest, block: Block, used_exclusive: set[str]) -> bool:
    if req.section_id != block.section_id or req.track_id != block.track_id:
        return False
    if not (block.block_start <= req.earliest_start and block.block_end >= req.latest_end):
        return False
    if block.remaining_duration_hrs < req.estimated_duration_hrs:
        return False
    exclusive_needed = set(req.required_resources) & EXCLUSIVE_RESOURCES
    if exclusive_needed & used_exclusive:
        return False
    return True


def build_edges(requests: list[ScoredRequest], blocks: list[Block]) -> dict[str, list[str]]:
    """request_id -> list of block_ids it could feasibly go into (ignoring
    the exclusive-resource-per-block cap, which is enforced at solve time
    since it depends on which other requests land in the same block)."""
    edges: dict[str, list[str]] = {}
    for req in requests:
        edges[req.request_id] = [
            b.block_id
            for b in blocks
            if req.section_id == b.section_id
            and req.track_id == b.track_id
            and b.block_start <= req.earliest_start
            and b.block_end >= req.latest_end
            and b.remaining_duration_hrs >= req.estimated_duration_hrs
        ]
    return edges
