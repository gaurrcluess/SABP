"""
Minimal in-memory store so GET /plans/{id}, /plans/weekly, /plans/monthly,
and /blocks have something to serve after a POST /optimization/generate.
Swap for a real DB when this moves past hackathon-demo scope.
"""

from __future__ import annotations

from app.models.schemas import OptimizationResponse

_plans: dict[str, OptimizationResponse] = {}
_latest_by_type: dict[str, str] = {}  # "weekly" | "monthly" -> plan_id


def save(plan: OptimizationResponse) -> None:
    _plans[plan.plan_id] = plan
    _latest_by_type[plan.period_type] = plan.plan_id


def get(plan_id: str) -> OptimizationResponse | None:
    return _plans.get(plan_id)


def get_latest(period_type: str) -> OptimizationResponse | None:
    plan_id = _latest_by_type.get(period_type)
    return _plans.get(plan_id) if plan_id else None


def all_blocks():
    blocks = []
    for plan in _plans.values():
        blocks.extend(plan.scheduled_blocks)
    return blocks
