"""
Weekly scheduler — exact solve via CP-SAT (small enough scale to solve
optimally within a time limit).

Decision variable x[req_id, block_id] in {0,1}: request assigned to block.
Maximize sum(priority_score[req] * x[req, block]) subject to:
  - each request assigned to at most one block (0 if genuinely infeasible)
  - only feasible (request, block) edges are decision variables at all
  - sum of durations of requests assigned to a block <= block's remaining capacity
  - exclusive resources (crane/possession_team/tamping_machine) used by at
    most one request per block
  - hard-priority requests (safety-critical + past SLA) are forced to 1
    whenever at least one feasible edge exists for them
"""

from __future__ import annotations

from ortools.sat.python import cp_model

from app.models.schemas import Block, ScoredRequest, ScheduledBlock, UnscheduledRequest
from app.services.feasibility import EXCLUSIVE_RESOURCES, build_edges
from app.services.scoring import is_hard_priority, priority_score, score_reasons

SCORE_SCALE = 100  # CP-SAT needs integers; scores are already 0-100 with 2dp -> scale up


def solve_weekly(requests: list[ScoredRequest], blocks: list[Block]):
    edges = build_edges(requests, blocks)
    scores = {r.request_id: priority_score(r) for r in requests}
    req_by_id = {r.request_id: r for r in requests}
    block_by_id = {b.block_id: b for b in blocks}

    model = cp_model.CpModel()
    x = {}
    for req_id, block_ids in edges.items():
        for block_id in block_ids:
            x[req_id, block_id] = model.NewBoolVar(f"x_{req_id}_{block_id}")

    # each request assigned at most once
    for req_id, block_ids in edges.items():
        if block_ids:
            model.Add(sum(x[req_id, b] for b in block_ids) <= 1)

    # capacity per block
    for block in blocks:
        assigned_here = [
            (req_id, block.block_id)
            for req_id, block_ids in edges.items()
            if block.block_id in block_ids
        ]
        if assigned_here:
            model.Add(
                sum(
                    int(req_by_id[r].estimated_duration_hrs * 100) * x[r, block.block_id]
                    for r, _ in assigned_here
                )
                <= int(block.remaining_duration_hrs * 100)
            )
        # at most one request per exclusive resource, per block
        for resource in EXCLUSIVE_RESOURCES:
            needing = [
                r
                for r, _ in assigned_here
                if resource in req_by_id[r].required_resources
            ]
            if len(needing) > 1:
                model.Add(sum(x[r, block.block_id] for r in needing) <= 1)

    # hard-priority requests: force assignment if any feasible edge exists
    for req_id, block_ids in edges.items():
        if block_ids and is_hard_priority(req_by_id[req_id]):
            model.Add(sum(x[req_id, b] for b in block_ids) == 1)

    objective_terms = [
        int(scores[req_id] * SCORE_SCALE) * x[req_id, block_id]
        for (req_id, block_id) in x
    ]
    if objective_terms:
        model.Maximize(sum(objective_terms))

    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = 10
    status = solver.Solve(model)

    scheduled: dict[str, list[str]] = {b.block_id: [] for b in blocks}
    unscheduled: list[UnscheduledRequest] = []
    scheduled_req_ids: set[str] = set()

    if status in (cp_model.OPTIMAL, cp_model.FEASIBLE):
        for (req_id, block_id), var in x.items():
            if solver.Value(var):
                scheduled[block_id].append(req_id)
                scheduled_req_ids.add(req_id)

    for req in requests:
        if req.request_id not in scheduled_req_ids:
            reason = (
                "No feasible block within track/time/resource constraints"
                if not edges.get(req.request_id)
                else "Not selected: capacity exhausted by higher-priority requests"
            )
            unscheduled.append(
                UnscheduledRequest(
                    request_id=req.request_id,
                    priority_score=scores[req.request_id],
                    reason=reason,
                )
            )

    scheduled_blocks = []
    for block in blocks:
        req_ids = scheduled[block.block_id]
        block_score = round(sum(scores[r] for r in req_ids), 2)
        reasons: list[str] = []
        for r in req_ids:
            reasons.extend(score_reasons(req_by_id[r], scores[r]))
        scheduled_blocks.append(
            ScheduledBlock(
                **block.model_dump(),
                scheduled_request_ids=req_ids,
                priority_score=block_score,
                optimization_reasons=reasons,
            )
        )

    total_possible = round(sum(scores.values()), 2)
    total_captured = round(sum(scores[r] for r in scheduled_req_ids), 2)
    return scheduled_blocks, unscheduled, total_captured, total_possible
