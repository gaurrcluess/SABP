"""
Priority scoring: P = w1*C + w2*U + w3*I, each term normalized to 0-10,
final score scaled to 0-100. Safety-critical requests are additionally
flagged as hard-priority (must be scheduled ahead of everything else,
independent of numeric score).
"""

from __future__ import annotations

from app.models.schemas import Criticality, ScoredRequest

CRITICALITY_WEIGHT = {
    Criticality.LOW: 2.5,
    Criticality.MEDIUM: 5.0,
    Criticality.HIGH: 7.5,
    Criticality.CRITICAL: 10.0,
}

W_CRITICALITY = 0.45
W_URGENCY = 0.30
W_IMPACT = 0.25

IMPACT_SATURATION_TRAINS = 20  # trains/day beyond which impact score maxes out


def urgency_score(req: ScoredRequest) -> float:
    ratio = req.overdue_days / req.sla_days
    return min(ratio, 1.0) * 10.0


def impact_score(req: ScoredRequest) -> float:
    ratio = req.impact_trains_affected / IMPACT_SATURATION_TRAINS
    return min(ratio, 1.0) * 10.0


def is_hard_priority(req: ScoredRequest) -> bool:
    """Safety-critical + already past SLA: must-schedule regardless of score."""
    return req.criticality == Criticality.CRITICAL and req.overdue_days >= req.sla_days


def priority_score(req: ScoredRequest) -> float:
    c = CRITICALITY_WEIGHT[req.criticality]
    u = urgency_score(req)
    i = impact_score(req)
    raw = W_CRITICALITY * c + W_URGENCY * u + W_IMPACT * i  # 0-10
    return round(raw * 10, 2)  # 0-100


def score_reasons(req: ScoredRequest, score: float) -> list[str]:
    reasons = [f"{req.criticality.value} criticality asset ({req.asset_type})"]
    if req.overdue_days > 0:
        reasons.append(f"Overdue by {req.overdue_days}d against {req.sla_days}d SLA")
    if req.impact_trains_affected > 0:
        reasons.append(f"Affects ~{req.impact_trains_affected} train services/day")
    if is_hard_priority(req):
        reasons.append("Hard-priority: safety-critical and past SLA")
    reasons.append(f"Priority score {score}/100")
    return reasons
