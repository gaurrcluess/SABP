"""
Monthly scheduler — genetic algorithm. Monthly horizons involve enough
requests/blocks that exact ILP stops scaling, so we use a repair-based GA:

  chromosome[i]  = index into requests[i]'s feasible-block list, or -1
                   (request left unscheduled)

Repair step resolves capacity / exclusive-resource conflicts by keeping
the higher-priority request and dropping the loser back to -1, so every
evaluated chromosome is guaranteed feasible. This keeps fitness = sum of
priority scores of requests that stayed scheduled after repair, no
penalty terms needed.
"""

from __future__ import annotations

import random

from app.models.schemas import Block, ScoredRequest, ScheduledBlock, UnscheduledRequest
from app.services.feasibility import EXCLUSIVE_RESOURCES, build_edges
from app.services.scoring import priority_score, score_reasons

POPULATION_SIZE = 60
GENERATIONS = 120
MUTATION_RATE = 0.15
TOURNAMENT_SIZE = 4


def _repair_and_score(chromosome, requests, edges, scores):
    """Greedily drop lower-priority requests that collide with a higher
    priority one on capacity or exclusive resources. Returns block_id ->
    [request_id] assignment after repair."""
    order = sorted(range(len(requests)), key=lambda i: scores[requests[i].request_id], reverse=True)

    used_duration: dict[str, float] = {}
    used_exclusive: dict[str, set[str]] = {}
    assignment: dict[str, list[str]] = {}

    for i in order:
        req = requests[i]
        gene = chromosome[i]
        feasible_blocks = edges[req.request_id]
        if gene == -1 or not feasible_blocks or gene >= len(feasible_blocks):
            continue
        block_id = feasible_blocks[gene]
        cap_used = used_duration.get(block_id, 0.0)
        excl_used = used_exclusive.get(block_id, set())
        needed_excl = set(req.required_resources) & EXCLUSIVE_RESOURCES

        block_cap = _BLOCK_CAP[block_id]
        if cap_used + req.estimated_duration_hrs > block_cap:
            continue
        if needed_excl & excl_used:
            continue

        used_duration[block_id] = cap_used + req.estimated_duration_hrs
        used_exclusive.setdefault(block_id, set()).update(needed_excl)
        assignment.setdefault(block_id, []).append(req.request_id)

    return assignment


_BLOCK_CAP: dict[str, float] = {}


def solve_monthly(requests: list[ScoredRequest], blocks: list[Block]):
    global _BLOCK_CAP
    edges = build_edges(requests, blocks)
    scores = {r.request_id: priority_score(r) for r in requests}
    req_by_id = {r.request_id: r for r in requests}
    _BLOCK_CAP = {b.block_id: b.remaining_duration_hrs for b in blocks}

    gene_ranges = [max(len(edges[r.request_id]), 1) for r in requests]  # >=1 so gene -1..n-1 valid

    def random_chromosome():
        return [random.randint(-1, gene_ranges[i] - 1) for i in range(len(requests))]

    def fitness(chromosome):
        assignment = _repair_and_score(chromosome, requests, edges, scores)
        scheduled_ids = {r for ids in assignment.values() for r in ids}
        return round(sum(scores[r] for r in scheduled_ids), 2), assignment

    population = [random_chromosome() for _ in range(POPULATION_SIZE)]
    best_chromosome, (best_fitness, best_assignment) = None, (-1.0, {})

    for _ in range(GENERATIONS):
        scored_pop = [(c, fitness(c)) for c in population]
        scored_pop.sort(key=lambda cs: cs[1][0], reverse=True)

        if scored_pop[0][1][0] > best_fitness:
            best_chromosome, (best_fitness, best_assignment) = scored_pop[0][0], scored_pop[0][1]

        next_gen = [scored_pop[0][0], scored_pop[1][0]]  # elitism
        while len(next_gen) < POPULATION_SIZE:
            p1 = _tournament(scored_pop)
            p2 = _tournament(scored_pop)
            cut = random.randint(1, len(requests) - 1) if len(requests) > 1 else 0
            child = p1[:cut] + p2[cut:]
            for i in range(len(child)):
                if random.random() < MUTATION_RATE:
                    child[i] = random.randint(-1, gene_ranges[i] - 1)
            next_gen.append(child)
        population = next_gen

    scheduled_req_ids = {r for ids in best_assignment.values() for r in ids}
    unscheduled = []
    for req in requests:
        if req.request_id not in scheduled_req_ids:
            reason = (
                "No feasible block within track/time/resource constraints"
                if not edges.get(req.request_id)
                else "Not selected by GA: capacity/resource conflict with higher-priority request"
            )
            unscheduled.append(
                UnscheduledRequest(
                    request_id=req.request_id, priority_score=scores[req.request_id], reason=reason
                )
            )

    scheduled_blocks = []
    for block in blocks:
        req_ids = best_assignment.get(block.block_id, [])
        block_score = round(sum(scores[r] for r in req_ids), 2)
        reasons = []
        for r in req_ids:
            reasons.extend(score_reasons(req_by_id[r], scores[r]))
        scheduled_blocks.append(
            ScheduledBlock(
                **block.model_dump(),
                scheduled_request_ids=req_ids,
                priority_score=block_score,
                optimization_reasons=reasons,
            )
        )

    total_possible = round(sum(scores.values()), 2)
    return scheduled_blocks, unscheduled, best_fitness, total_possible


def _tournament(scored_pop):
    contenders = random.sample(scored_pop, min(TOURNAMENT_SIZE, len(scored_pop)))
    return max(contenders, key=lambda cs: cs[1][0])[0]
