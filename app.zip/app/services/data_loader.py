from __future__ import annotations

import csv
from datetime import datetime
from pathlib import Path

from app.models.schemas import Block, Criticality, PlanningCalendar, ScoredRequest

DATA_DIR = Path(__file__).resolve().parent.parent.parent / "data"


def load_requests(path: Path = DATA_DIR / "maintenance_requests.csv") -> list[ScoredRequest]:
    with open(path, newline="") as f:
        rows = list(csv.DictReader(f))
    return [
        ScoredRequest(
            request_id=row["request_id"],
            section_id=row["section_id"],
            track_id=row["track_id"],
            asset_type=row["asset_type"],
            department=row["department"],
            earliest_start=datetime.fromisoformat(row["earliest_start"]),
            latest_end=datetime.fromisoformat(row["latest_end"]),
            estimated_duration_hrs=float(row["estimated_duration_hrs"]),
            required_resources=row["required_resources"],
            criticality=Criticality(row["criticality"]),
            overdue_days=int(row["overdue_days"]),
            sla_days=int(row["sla_days"]),
            impact_trains_affected=int(row["impact_trains_affected"]),
        )
        for row in rows
    ]


def load_blocks(path: Path = DATA_DIR / "current_blocks.csv") -> list[Block]:
    with open(path, newline="") as f:
        rows = list(csv.DictReader(f))
    return [
        Block(
            block_id=row["block_id"],
            section_id=row["section_id"],
            track_id=row["track_id"],
            block_start=datetime.fromisoformat(row["block_start"]),
            block_end=datetime.fromisoformat(row["block_end"]),
            allocated_duration_hrs=float(row["allocated_duration_hrs"]),
            used_duration_hrs=float(row["used_duration_hrs"]),
            assigned_resources=row["assigned_resources"],
        )
        for row in rows
    ]


def load_calendar(path: Path = DATA_DIR / "planning_calendar.csv") -> PlanningCalendar:
    with open(path, newline="") as f:
        row = next(csv.DictReader(f))
    return PlanningCalendar(
        period_id=row["period_id"],
        period_type=row["period_type"],
        start_date=datetime.fromisoformat(row["start_date"]),
        end_date=datetime.fromisoformat(row["end_date"]),
    )
